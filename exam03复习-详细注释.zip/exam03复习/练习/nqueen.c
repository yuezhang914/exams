/* n_queens_annotated.c
 * 与 subject_n_queens.txt 对齐的逐行中文注释版本
 */

// Assignement name : n_queens

// Expected files : *.c *.h

// Allowed functions : atoi, fprintf, write

// -------------------------------------------------------------------------

// Write a program that will print all the solutions to the n queens problem
// for a n given as argument.
// We will not test with negative values.
// The order of the solutions is not important.

// You will display the solutions under the following format :
// <p1> <p2> <p3> ... \n
// where pn are the line index of the queen in each colum starting from 0.

// For example this should work :
// $> ./n_queens 2 | cat -e

// $> ./n_queens 4 | cat -e
// 1 3 0 2$
// 2 0 3 1$

// $> ./n_queens 7 | cat -e
// 0 2 4 6 1 3 5$
// 0 3 6 2 5 1 4$

/*
 * 题目：n_queens
 * 允许函数：atoi, fprintf, write
 *
 * 功能：
 *  - 接收一个参数 n
 *  - 打印 n 皇后问题的所有解
 *  - 输出格式：每列一个数字，表示该列皇后所在行（从 0 开始），数字之间空格分隔
 *
 * 思路（初中生版）：
 *  1) 用 positions 数组存解：
 *     positions[col] = row
 *     意思是：第 col 列的皇后放在第 row 行
 *  2) 我们从第 0 列开始一列一列放：
 *     - 当前列尝试每一行
 *     - 如果和之前列的皇后不冲突，就放下去，递归处理下一列
 *     - 如果后面放不下，就回退，换下一行继续试（回溯）
 */
