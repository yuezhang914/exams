/* permutations_fixed.c
 * 对原始两个版本的改进与合并（以第二版为基础，做了拷贝排序、内存检查与重复检测）
 * 仅使用被允许的函数（malloc, calloc, free, write），移除了未使用的 stdio 头文件
 */
// Assignment name : permutations

// Expected files : *.c *.h
// Allowed functions : puts, malloc, calloc, realloc, free, write
// ---------------------------------------------------------------

// Write a program that will print all the permutations of a string given as argument.

// The solutions must be given in alphabetical order.

// We will not try your program with strings containing duplicates (eg: 'abccd')

// For example this should work:
// $> ./permutations a | cat -e
// a$
// $> ./permutations ab | cat -e
// ab$
// ba$
// $> ./permutations abc | cat -e
// abc$
// acb$
// bac$
// bca$
// cab$
// cba$

/*
 * 题目：permutations
 * 允许函数：puts, malloc, calloc, realloc, free, write
 *
 * 功能：
 *  - 程序接收一个字符串参数（题目保证没有重复字符）
 *  - 打印该字符串的所有排列
 *  - 输出必须按字典序（alphabetical order）
 *
 * 核心思路（初中生版）：
 *  1) 把输入字符串复制一份（src_copy），并排序成从小到大
 *  2) 用回溯（试错）生成所有排列：
 *     - res 用来保存当前正在拼的排列
 *     - used[i] 记录 src_copy[i] 这个字符是否已经用过
 *  3) 当 res 拼满（depth == len）就输出
 */
