/* permutations_fixed.c
 * 对原始两个版本的改进与合并（以第二版为基础，做了拷贝排序、内存检查与重复检测）
 * 仅使用被允许的函数（malloc, calloc, free, write），移除了未使用的 stdio 头文件
 */
// Assignment name : permutations

// Expected files : *.c *.h
// Allowed functions : puts, malloc, calloc, realloc, free, write
// ---------------------------------------------------------------

// Write a program that will print all the permutations of a string given as argument.

// The solutions must be given in alphabetical order.

// We will not try your program with strings containing duplicates (eg: 'abccd')

// For example this should work:
// $> ./permutations a | cat -e
// a$
// $> ./permutations ab | cat -e
// ab$
// ba$
// $> ./permutations abc | cat -e
// abc$
// acb$
// bac$
// bca$
// cab$
// cba$

/*
 * 题目：permutations
 * 允许函数：puts, malloc, calloc, realloc, free, write
 *
 * 功能：
 *  - 程序接收一个字符串参数（题目保证没有重复字符）
 *  - 打印该字符串的所有排列
 *  - 输出必须按字典序（alphabetical order）
 *
 * 核心思路（初中生版）：
 *  1) 把输入字符串复制一份（src_copy），并排序成从小到大
 *  2) 用回溯（试错）生成所有排列：
 *     - res 用来保存当前正在拼的排列
 *     - used[i] 记录 src_copy[i] 这个字符是否已经用过
 *  3) 当 res 拼满（depth == len）就输出
 */

#include <stdio.h>  /* puts */
#include <stdlib.h> /* malloc, calloc, free */

/*
 * ft_strlen
 *
 * 作用：
 *  - 计算字符串长度（不包含结尾的 '\0'）
 *
 * 为什么要自己写？
 *  - 题目允许函数里没有 strlen，所以我们自己实现
 */
static int	ft_strlen(const char *s)
{
	int	len;

	len = 0;
	while (s[len] != '\0')
		len = len + 1;
	return (len);
}

/*
 * sort_string
 *
 * 作用：
 *  - 把字符串 s 按从小到大排序（字典序需要这个）
 *
 * 方法：
 *  - 这里用最容易理解的“交换排序”（类似冒泡/选择的混合）
 *  - 两层 while：如果前面字符比后面大就交换
 *
 * 注意：
 *  - s 必须是“可写”的字符串，所以我们对 src_copy 排序
 *  - 不直接改 av[1]（有的系统里 argv 的内容不建议乱改）
 */
static void	sort_string(char *s)
{
	int		i;
	int		j;
	char	tmp;

	i = 0;
	while (s[i] != '\0')
	{
		j = i + 1;
		while (s[j] != '\0')
		{
			if (s[i] > s[j])
			{
				tmp = s[i];
				s[i] = s[j];
				s[j] = tmp;
			}
			j = j + 1;
		}
		i = i + 1;
	}
}

/*
 * generate
 *
 * 作用（回溯核心）：
 *  - 在第 depth 个位置选择一个还没用过的字符，放到 res[depth]
 *  - 然后递归去填 res[depth + 1]
 *  - 当 depth == len，说明 res 已经填满，是一个完整排列 -> 输出
 *
 * 参数解释：
 *  - src   ：已经排好序的源字符串（只读，不改它）
 *  - res   ：结果缓冲区，用来拼当前排列（可写）
 *  - used  ：标记数组，used[i] = 1 表示 src[i] 已经在 res 里用过
 *  - len   ：字符串长度
 *  - depth ：当前要填 res 的第几个位置（从 0 开始）
 *
 * 为什么 res 可以直接 puts 输出？
 *  - 因为我们会提前设置 res[len] = '\0'
 *  - 这样 res 永远是一条合法 C 字符串
 */
static void	generate(const char *src, char *res, int *used, int len, int depth)
{
	int	i;

	/* 递归终点：res 已经填满 len 个字符 */
	if (depth == len)
	{
		puts(res); /* puts 会自动在末尾加 '\n' */
		return ;
	}
	/*
		* 这一层要做的事：
		*  - 依次尝试 src 的每个字符（从小到大，所以输出就是字典序）
		*  - 如果 used[i] == 0，说明这个字符还没被用过，可以选
		*/
	i = 0;
	while (i < len)
	{
		if (used[i] == 0)
		{
			/* 1) 选择：把 src[i] 放进 res[depth] */
			used[i] = 1;
			res[depth] = src[i];
			/* 2) 递归：去填下一个位置 depth+1 */
			generate(src, res, used, len, depth + 1);
			/* 3) 回溯：撤销选择，让这个字符“恢复未使用” */
			used[i] = 0;
			/*
				* 注意：res[depth] 不用清空
				* 因为下一次选择会覆盖它
				*/
		}
		i = i + 1;
	}
}

/*
 * main
 *
 * 作用：
 *  - 检查参数数量
 *  - 计算长度 len
 *  - 分配三块核心内存：
 *    1) src_copy：输入字符串拷贝（可写，用来排序）
 *    2) res：当前排列结果缓冲（长度 len+1）
 *    3) used：标记数组（长度 len），calloc 自动清零
 *  - 排序 src_copy
 *  - 调用 generate 开始回溯
 *  - 释放内存
 *
 * 关于空字符串：
 *  - 如果输入是 ""（长度 0），有两种合理选择：
 *    A) 输出一行空行（空排列）
 *    B) 返回 1 表示无意义
 *  - 题目一般不会给空字符串。这里我们选择：len==0 -> 返回 1
 */
int	main(int ac, char **av)
{
	int		len;
	char	*src_copy;
	char	*res;
	int		*used;
	int		i;

	/* 参数必须刚好一个：程序名 + 字符串 */
	if (ac != 2)
		return (1);
	/* 计算输入字符串长度 */
	len = ft_strlen(av[1]);
	if (len == 0)
		return (1);
	/* 分配 src_copy：len + 1 给 '\0' */
	src_copy = (char *)malloc((len + 1) * sizeof(char));
	if (src_copy == NULL)
		return (1);
	/* 把 av[1] 拷贝到 src_copy（逐字符拷贝，不用 memcpy） */
	i = 0;
	while (i < len)
	{
		src_copy[i] = av[1][i];
		i = i + 1;
	}
	src_copy[len] = '\0';
	/* 排序，保证后续生成按字典序输出 */
	sort_string(src_copy);
	/* 分配 res：len + 1，并提前放好结尾 '\0' */
	res = (char *)malloc((len + 1) * sizeof(char));
	if (res == NULL)
	{
		free(src_copy);
		return (1);
	}
	res[len] = '\0'; /* 非常关键：这样 puts(res) 才知道哪里结束 */
	/* 分配 used：calloc 会把所有 int 初始化为 0（未使用） */
	used = (int *)calloc(len, sizeof(int));
	if (used == NULL)
	{
		free(src_copy);
		free(res);
		return (1);
	}
	/* 开始回溯：从第 0 个位置开始填 res */
	generate(src_copy, res, used, len, 0);
	/* 清理资源 */
	free(src_copy);
	free(res);
	free(used);
	return (0);
}

// /*
//  * permutations.c
//  *
//  * 功能说明（总体）：
//  *   接收一个字符串参数（不含重复字符），打印该字符串的所有排列，
//  *   并按字典（字母）顺序输出，每个排列一行。
//  *
//  * 允许使用的函数：puts, malloc, calloc, realloc, free, write
//  *
//  * 我对你的原实现做了小幅修正：
//  * - 为结果缓冲设置 NUL 终止符，从而使用 puts 输出更方便；
//  * - 当 len == 0 时返回 1（可按需改成输出空行）；
//  * - 保持所有循环使用 while，不使用 for；
//  * - 添加逐函数功能说明与逐行注释，便于理解与维护。
//  */

// #include <stdio.h>  /* puts 函数声明（允许使用） */
// #include <stdlib.h> /* malloc, calloc, free */
// #include <unistd.h> /* write 函数声明（保留，以防需要） */

// /* has_dup:
//  * 作用：检查传入字符串是否包含重复字符。
//  * 返回值：若存在重复返回 1；否则返回 0。
//  * 说明：题目保证不会有重复字符，此函数只是保守检查，可选保留。
//  */
// int	has_dup(const char *str)
// {
// 	int	i;
// 	int	j;

// 	i = 0;                 /* 外层索引从 0 开始 */
// 	while (str[i] != '\0') /* 遍历每个字符 */
// 	{
// 		j = i + 1;             /* 内层从 i+1 开始比较 */
// 		while (str[j] != '\0') /* 比较 i 与后续所有字符 */
// 		{
// 			if (str[i] == str[j]) /* 若发现相等则存在重复 */
// 				return (1);
// 			j = j + 1; /* 内层索引递增 */
// 		}
// 		i = i + 1; /* 外层索引递增 */
// 	}
// 	return (0); /* 没有发现重复 */
// }

// /* ft_strlen:
//  * 作用：计算字符串长度（等价于 strlen）。
//  * 返回值：字符串长度（不包含终止符）。
//  */
// int	ft_strlen(const char *str)
// {
// 	int	len;

// 	len = 0;                 /* 初始化计数为 0 */
// 	while (str[len] != '\0') /* 循环直到 NUL 终止符 */
// 		len = len + 1;       /* 递增计数 */
// 	return (len);            /* 返回长度 */
// }

// /* sort_string:
//  * 作用：就地对字符串 s 进行升序排序（字典序），使用交换排序（嵌套循环）。
//  * 说明：使用 while 循环实现，不使用 for。
//  */
// void	sort_string(char *s)
// {
// 	int		i;
// 	int		j;
// 	char	tmp;

// 	if (!s) /* 保护性检查：若 s 为 NULL 则直接返回 */
// 		return ;
// 	i = 0;
// 	while (s[i] != '\0') /* 外层 i 遍历每个位置 */
// 	{
// 		j = i + 1;           /* j 从 i+1 开始比较 */
// 		while (s[j] != '\0') /* 内层 j 用来找到比 s[i] 更小的字符并交换 */
// 		{
// 			if (s[i] > s[j]) /* 如果 s[i] 大于 s[j] 则交换两者 */
// 			{
// 				tmp = s[i];
// 				s[i] = s[j];
// 				s[j] = tmp;
// 			}
// 			j = j + 1; /* j++ */
// 		}
// 		i = i + 1; /* i++ */
// 	}
// }

// /* generate:
//  * 作用：回溯生成所有排列并输出。
//  *
//  * 参数说明：
//  * - src: 已排序的源字符串（只读）
//  * - res: 结果缓冲（长度至少为 len + 1），函数保证 res[len] = '\0'
//  * - used: 标志数组，长度为 len，0 表示未用，1 表示已用
//  * - len: 字符串长度
//  * - depth: 当前构造深度（从 0 到 len）
//  *
//  * 工作流程：
//  * - 若 depth == len，则 res 已构成一个完整排列，使用 puts 输出（自动换行）；
//  * - 否则遍历 src 的每个位置 i，若 used[i] == 0，
//  *   则把 src[i] 放到 res[depth]，标记 used[i] = 1，递归处理 depth + 1，回溯时将 used[i] = 0。
//  */
// void	generate(const char *src, char *res, int *used, int len, int depth)
// {
// 	int	i;

// 	if (depth == len) /* 递归终点：已构造完整排列 */
// 	{
// 		/* res 事先保证以 NUL 结尾，因此可以使用 puts 输出并自动换行 */
// 		puts(res);
// 		return ; /* 返回上一层以继续生成其他排列 */
// 	}
// 	i = 0;
// 	while (i < len) /* 遍历 src 中的每个字符位置 */
// 	{
// 		if (used[i] == 0) /* 若该字符尚未被使用 */
// 		{
// 			used[i] = 1;         /* 标记为已用 */
// 			res[depth] = src[i]; /* 将字符放到当前深度的位置 */
// 			/* 递归生成下一深度的排列 */
// 			generate(src, res, used, len, depth + 1);
// 			/* 回溯：恢复 used 标志为未用，供后续排列使用 */
// 			used[i] = 0;
// 		}
// 		i = i + 1; /* i++，继续尝试下一个字符 */
// 	}
// }

// /* main:
//  * 作用：主程序入口，负责参数检查、内存分配、排序、调用生成函数、清理资源。
//  *
//  * 步骤：
//  * - 检查参数数量，若不为 2（程序名 + 字符串）则返回 1；
//  * - 可选地检查重复字符（此题不必检查，因为题目保证无重复）；
//  * - 计算长度 len，若 len == 0 则返回 1（可根据需求修改）；
//  * - 分配 src_copy、res、used 等缓冲，并初始化必要元素（如 res[len] = '\0'）；
//  * - 对 src_copy 进行排序，调用 generate 生成并输出所有排列；
//  * - 释放内存并返回 0。
//  */
// int	main(int ac, char **av)
// {
// 	int		len;
// 	char	*src_copy;
// 	char	*res;
// 	int		*used;
// 	int		i;

// 	/* 参数检查：程序需接收且仅接收一个参数 */
// 	if (ac != 2)
// 		return (1);
// 	/* 可选：检测重复字符；若发现重复则视为错误并返回 1 */
// 	if (has_dup(av[1]))
// 		return (1);
// 	/* 计算字符串长度 */
// 	len = ft_strlen(av[1]);
// 	/* 若字符串为空（len == 0），返回 1（按题目可选行为） */
// 	if (len == 0)
// 		return (1);
// 	/* 分配 src_copy，并把 argv[1] 拷贝到 src_copy 中以便就地排序 */
// 	src_copy = (char *)malloc((len + 1) * sizeof(char));
// 	if (!src_copy)
// 		return (1);
// 	i = 0;
// 	while (i < len)
// 	{
// 		src_copy[i] = av[1][i];
// 		i = i + 1;
// 	}
// 	src_copy[len] = '\0'; /* NUL 终止符 */
// 	/* 排序源字符串，确保字典序的起点是最小排列 */
// 	sort_string(src_copy);
// 	/* 为结果缓冲分配空间，并设置终止符，方便使用 puts 输出 */
// 	res = (char *)malloc((len + 1) * sizeof(char));
// 	if (!res)
// 	{
// 		free(src_copy);
// 		return (1);
// 	}
// 	res[len] = '\0'; /* 预置 NUL 终止符 */
// 	/* 分配并初始化 used 标志数组（calloc 会将内存置 0） */
// 	used = (int *)calloc(len, sizeof(int));
// 	if (!used)
// 	{
// 		free(src_copy);
// 		free(res);
// 		return (1);
// 	}
// 	/* 调用回溯生成所有排列并输出 */
// 	generate(src_copy, res, used, len, 0);
// 	/* 释放资源并返回成功 */
// 	free(src_copy);
// 	free(res);
// 	free(used);
// 	return (0);
// }
