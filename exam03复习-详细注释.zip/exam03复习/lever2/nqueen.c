/* n_queens_annotated.c
 * 与 subject_n_queens.txt 对齐的逐行中文注释版本
 */

// Assignement name : n_queens

// Expected files : *.c *.h

// Allowed functions : atoi, fprintf, write

// -------------------------------------------------------------------------

// Write a program that will print all the solutions to the n queens problem
// for a n given as argument.
// We will not test with negative values.
// The order of the solutions is not important.

// You will display the solutions under the following format :
// <p1> <p2> <p3> ... \n
// where pn are the line index of the queen in each colum starting from 0.

// For example this should work :
// $> ./n_queens 2 | cat -e

// $> ./n_queens 4 | cat -e
// 1 3 0 2$
// 2 0 3 1$

// $> ./n_queens 7 | cat -e
// 0 2 4 6 1 3 5$
// 0 3 6 2 5 1 4$

/*
 * 题目：n_queens
 * 允许函数：atoi, fprintf, write
 *
 * 功能：
 *  - 接收一个参数 n
 *  - 打印 n 皇后问题的所有解
 *  - 输出格式：每列一个数字，表示该列皇后所在行（从 0 开始），数字之间空格分隔
 *
 * 思路（初中生版）：
 *  1) 用 positions 数组存解：
 *     positions[col] = row
 *     意思是：第 col 列的皇后放在第 row 行
 *  2) 我们从第 0 列开始一列一列放：
 *     - 当前列尝试每一行
 *     - 如果和之前列的皇后不冲突，就放下去，递归处理下一列
 *     - 如果后面放不下，就回退，换下一行继续试（回溯）
 */

#include <stdio.h>  /* fprintf */
#include <stdlib.h> /* atoi */

/*
 * is_safe
 *
 * 作用：
 *  - 判断：如果我想在 (current_row, current_col) 放一个皇后
 *    会不会和前面已经放好的皇后打架（冲突）
 *
 * 参数解释：
 *  - positions：一个数组（传进来会变成指针 int *）
 *      positions[c] 表示第 c 列皇后所在的行
 *  - current_col：当前要放皇后的列（从 0 开始）
 *  - current_row：当前尝试放皇后的行（从 0 开始）
 *
 * 返回值：
 *  - 1：安全，可以放
 *  - 0：不安全，不能放
 *
 * 为什么只检查 “之前的列”？
 *  - 因为我们是一列一列从左往右放的
 *  - current_col 右边的列还没放皇后，所以不用检查
 */
static int	is_safe(int *positions, int current_col, int current_row)
{
	int prev_col; /* 用来遍历之前的列：0 ~ current_col-1 */
	int prev_row; /* 之前某一列皇后所在的行 */
	prev_col = 0;
	while (prev_col < current_col)
	{
		prev_row = positions[prev_col];
		/* 1) 同一行冲突：
			* 如果之前皇后行 == 当前想放的行 -> 会互相攻击
			*/
		if (prev_row == current_row)
			return (0);
		/* 2) 主对角线冲突（\ 方向）：
			* 特点：row - col 相等
			*/
		if (prev_row - prev_col == current_row - current_col)
			return (0);
		/* 3) 副对角线冲突（/ 方向）：
			* 特点：row + col 相等
			*/
		if (prev_row + prev_col == current_row + current_col)
			return (0);
		prev_col = prev_col + 1;
	}
	/* 前面所有皇后都不冲突，安全 */
	return (1);
}

/*
 * print_solution
 *
 * 作用：
 *  - 当我们已经成功放好了 n 列（n 个皇后），就输出一行解
 *
 * 输出格式：
 *  positions[0] positions[1] ... positions[n-1]\n
 *
 * 参数：
 *  - positions：解数组
 *  - n：棋盘大小
 */
static void	print_solution(int *positions, int n)
{
	int	i;

	i = 0;
	while (i < n)
	{
		if (i > 0)
			fprintf(stdout, " "); /* 数字之间加空格，第一项前不加 */
		fprintf(stdout, "%d", positions[i]);
		i = i + 1;
	}
	fprintf(stdout, "\n");
}

/*
 * solve
 *
 * 作用（回溯核心）：
 *  - 尝试在第 col 列放皇后
 *  - 如果 col == n，说明 0..n-1 列都放好了 -> 输出一个解
 *
 * 参数：
 *  - positions：存放已放好的皇后位置
 *  - col：当前要处理的列
 *  - n：棋盘大小
 *
 * 这个函数怎么“试错”？
 *  - 对当前列 col，从 row=0 到 row=n-1 依次尝试
 *  - 能放就记下来 positions[col]=row，然后递归去放下一列 col+1
 *  - 递归返回后，继续试下一行（这就是回溯）
 */
static void	solve(int *positions, int col, int n)
{
	int	row;

	/* 递归终点：所有列都放好了 */
	if (col == n)
	{
		print_solution(positions, n);
		return ;
	}
	row = 0;
	while (row < n)
	{
		/* 如果在 (row, col) 放皇后是安全的 */
		if (is_safe(positions, col, row))
		{
			/* 记录：第 col 列的皇后放在 row 行 */
			positions[col] = row;
			/* 继续处理下一列 */
			solve(positions, col + 1, n);
			/* 回溯说明：
				* 这里不用“清除 positions[col]”
				* 因为下一次尝试别的 row 会把 positions[col] 覆盖掉
				*/
		}
		row = row + 1;
	}
}

/*
 * main
 *
 * 作用：
 *  - 解析参数 n
 *  - 创建 positions 数组
 *  - 从第 0 列开始求解
 *
 * 注意：你之前那份代码里最容易写错的是：
 *  int n;
 *  int positions[n];  // ❌ n 还没赋值就拿来当数组长度，会出问题
 *
 * 正确做法：
 *  先算出 n，再声明 positions[n]
 */
int	main(int ac, char **av)
{
	int	n;

	/* 参数必须恰好一个 */
	if (ac != 2)
		return (1);
	/* 把字符串转成整数 n */
	n = atoi(av[1]);
	/* n 必须 > 0（题目说不会给负数，但我们做保护） */
	if (n <= 0)
		return (1);
	/* 关键：在 n 已经确定之后，再声明变长数组 positions[n]
		* 用一个新的代码块，让 C 编译器更容易接受（C99 支持）
		*/
	{
		int positions[n]; /* positions[col] = row */
		/* 从第 0 列开始放皇后 */
		solve(positions, 0, n);
	}
	return (0);
}

// /*
//  * n_queens.c
//  *
//  * 说明：
//  * - 题目允许的函数：atoi, fprintf, write
//  * - 本实现未使用 malloc/printf/for，全部循环使用 while，
//  *   输出使用 fprintf(stdout, ...)（允许）。
//  * - 使用可变长数组 (VLA) int positions[n] 存放每列的皇后行号，
//  *   这样无需动态分配堆内存。
//  *
//  * 直接编译示例：
//  * gcc -std=c99 -Wall -Wextra -o n_queens n_queens.c
//  */

// /* 包含需要的头文件：
//  * - stdio.h 提供 fprintf (用于输出到 stdout/stderr)
//  * - stdlib.h 提供 atoi (用于解析命令行参数)
//  */
// #include <stdio.h>
// #include <stdlib.h>

// /* is_safe:
//  * 作用（高中生能懂）：
//  *   判断在列 current_col 放置皇后到行 current_row 是否与之前已放的皇后冲突。
//  *   如果与之前任一皇后同一行、同一主对角或同一副对角，返回 0（不安全）。
//  *   否则返回 1（安全）。
//  *
//  * 参数：
//  *   positions: 整数数组，positions[c] 表示第 c 列上皇后放在的行号
//  *   current_col: 当前要放皇后的列索引（0-based）
//  *   current_row: 尝试放皇后的行索引（0-based）
//  */
// int	is_safe(int *positions, int current_col, int current_row)
// {
// 	int	prev_col;
// 	int	prev_row;

// 	/* prev_col 用来遍历之前已放置皇后的列，从 0 到 current_col - 1 */
// 	prev_col = 0;
// 	/* 只需检查之前放置的列 */
// 	while (prev_col < current_col)
// 	{
// 		/* 读取 prev_col 列上皇后所在的行 */
// 		prev_row = positions[prev_col];
// 		/* 检查是否同一行：
// 			* 如果 prev_row == current_row，说明两个皇后在同一行，会互相攻击 */
// 		if (prev_row == current_row)
// 			return (0); /* 冲突，返回不安全 */
// 		/* 检查主对角线冲突（行-列相等）：prev_row - prev_col == current_row - current_col */
// 		if (prev_row - prev_col == current_row - current_col)
// 			return (0); /* 冲突，返回不安全 */
// 		/* 检查副对角线冲突（行+列相等）：prev_row + prev_col == current_row + current_col */
// 		if (prev_row + prev_col == current_row + current_col)
// 			return (0); /* 冲突，返回不安全 */
// 		/* 检查下一个已放置的皇后 */
// 		prev_col = prev_col + 1;
// 	}
// 	/* 没有发现冲突，返回安全 */
// 	return (1);
// }

// /* solve:
//  * 作用（高中生能懂）：
//  *   使用回溯法在第 col 列放置皇后并递归处理后续列。
//  *   当 col == n 时说明所有列都放好了，打印一组解。
//  *
//  * 参数：
//  *   positions: 存放每列皇后行索引的数组（长度 n）
//  *   col: 当前正在处理的列索引
//  *   n: 棋盘大小（列数/行数）
//  */
// void	solve(int *positions, int col, int n)
// {
// 	int	row;

// 	/* 如果 col == n，说明所有列都放置完成，打印当前解 */
// 	if (col == n)
// 	{
// 		int i = 0; /* 用来遍历 positions 数组 */
// 		/* 逐个输出 positions[i]，数字之间用空格分隔 */
// 		while (i < n)
// 		{
// 			if (i > 0)
// 			{
// 				/* 在每个数字前输出一个空格（第一个数字前不输出） */
// 				/* 使用 fprintf 输出到 stdout（allowed） */
// 				fprintf(stdout, " ");
// 			}
// 			/* 输出第 i 列皇后所在的行索引（0-based） */
// 			fprintf(stdout, "%d", positions[i]);
// 			i = i + 1;
// 		}
// 		/* 当前解输出完毕，换行 */
// 		fprintf(stdout, "\n");
// 		return ; /* 返回上一层继续寻找其它解 */
// 	}
// 	/* 在当前列 col 逐行尝试放置皇后（从行 0 到 n-1） */
// 	row = 0;
// 	while (row < n)
// 	{
// 		/* 先判断在 (row, col) 放置是否安全 */
// 		if (is_safe(positions, col, row))
// 		{
// 			/* 记录当前列的放置行 */
// 			positions[col] = row;
// 			/* 递归尝试放置下一列 */
// 			solve(positions, col + 1, n);
// 			/* 回溯：不需要显式清除 positions[col]，下次会被覆盖 */
// 		}
// 		/* 尝试下一行 */
// 		row = row + 1;
// 	}
// }

// /* main:
//  * 作用（高中生能懂）：
//  *   解析命令行参数 n（使用 atoi），若参数合法则初始化 positions 数组并
//  *   调用 solve(…, 0, n) 来开始回溯求解，最后返回 0。
//  *   参数不合法时返回 1。
//  */
// int	main(int ac, char **av)
// {
// 	int	n;
// 	int	positions[n];

// 	/* 参数检查：必须且只有一个参数，并且参数非空 */
// 	if (ac != 2 || av[1][0] == '\0')
// 	{
// 		/* 参数格式不对，返回错误码 1 */
// 		return (1);
// 	}
// 	/* 把参数字符串转换为整数 n */
// 	n = atoi(av[1]);
// 	/* 如果 n <= 0，则视为非法（题目说明不会给负值，但我们做防护） */
// 	if (n <= 0)
// 		return (1);
// 	/* 使用 VLA（变量长度数组）在栈上分配 positions 数组，长度为 n
// 		* 这样避免使用 malloc（题目允许的函数列表中没有 malloc）
// 		*/
// 	/* 从第 0 列开始回溯求解 */
// 	solve(positions, 0, n);
// 	/* 正常结束，返回 0 */
// 	return (0);
// }
